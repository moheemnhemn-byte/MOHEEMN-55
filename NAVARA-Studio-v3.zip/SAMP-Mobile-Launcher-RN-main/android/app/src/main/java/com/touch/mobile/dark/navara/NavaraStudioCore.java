package com.touch.mobile.dark.navara;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import android.widget.HorizontalScrollView;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * NAVARA Studio - in-game overlay.
 * Phase 1: floating button, panel, per-system Pawn file editor (real save + backup + check).
 * Features that need native/server layers are shown as disabled with the reason.
 */
public class NavaraStudioCore {

    private static final String[][] DEFAULT_SYSTEMS = {
            {"🗺️ الخريطة", "map", "الخريطة والمواقع"},
            {"🏢 المباني", "buildings", "المباني والداخليات"},
            {"👮 الشرطة", "police", "الشرطة والرتب والسجن"},
            {"🪖 الجيش", "army", "الجيش والقواعد والنقاط"},
            {"🏴 العصابات", "gangs", "العصابات والمناطق"},
            {"🚑 الطبابة", "medical", "الإسعاف والعلاج"},
            {"👑 الإدارة", "admin", "أوامر وصلاحيات الإدارة"},
            {"📱 الهاتف", "phone", "نظام الهاتف"},
            {"🚨 الرهائن", "hostage", "نظام الرهائن"},
            {"⚔️ Capture", "capture", "مناطق الاستيلاء"},
            {"🏪 المحلات", "shops", "المحلات والأسعار"},
            {"🚗 المركبات", "vehicles", "المركبات والمعارض"},
            {"🏠 البيوت", "houses", "البيوت والتملك"},
            {"💼 الوظائف", "jobs", "الوظائف والرواتب"},
            {"🎯 المهام", "missions", "المهام والسلاسل"},
            {"👤 NPC", "npc", "الشخصيات غير اللاعبة"},
            {"👕 الملابس", "clothing", "الملابس والسكنات"},
            {"💰 الاقتصاد", "economy", "الأموال والأسعار"},
            {"🏦 البنك", "bank", "الحسابات والتحويل"},
            {"⛽ الوقود", "fuel", "محطات الوقود"},
            {"🏥 المستشفى", "hospital", "المستشفيات"},
            {"🎒 الحقيبة", "inventory", "الحقيبة والأغراض"},
            {"🎨 الواجهة", "ui_hud", "الواجهة وHUD"},
            {"💬 الحوارات", "dialogues", "الحوارات"},
            {"🔔 الإشعارات", "notifications", "الإشعارات"},
            {"⚙️ إعدادات السيرفر", "server_settings", "إعدادات السيرفر"}
    };

    private final Activity activity;
    private FrameLayout uiLayout;
    private Button fab;
    private FrameLayout panelRoot;
    private LinearLayout content;
    private final File projectDir;
    private final File backupDir;

    public NavaraStudioCore(Activity activity) {
        this.activity = activity;
        File base = activity.getExternalFilesDir(null);
        if (base == null) base = activity.getFilesDir();
        projectDir = new File(base, "NavaraProjects/default");
        backupDir = new File(projectDir, "backups");
        projectDir.mkdirs();
        backupDir.mkdirs();
        String saved = readFile(new File(projectDir, "objects.json"));
        if (!saved.trim().isEmpty()) restore(saved);
    }

    private int dp(int v) {
        return (int) (v * activity.getResources().getDisplayMetrics().density);
    }

    /** Shows only a small floating button. The game stays fully controllable. */
    public void attach() {
        if (fab != null) return;
        uiLayout = activity.findViewById(com.touch.mobile.dark.R.id.ui_layout);
        if (uiLayout == null) return;

        fab = new Button(activity);
        fab.setText("🛠");
        fab.setAllCaps(false);
        fab.setTextColor(Color.WHITE);
        fab.setBackground(rounded(Color.argb(200, 18, 23, 31), 24));
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP | Gravity.END);
        p.setMargins(0, dp(8), dp(8), 0);
        fab.setOnClickListener(v -> openHud());
        uiLayout.addView(fab, p);
    }

    private void openPanel() {
        if (panelRoot != null) return;
        panelRoot = new FrameLayout(activity);
        panelRoot.setBackgroundColor(Color.argb(235, 10, 13, 18));
        panelRoot.setClickable(true); // block touches to the game only while Studio is open

        LinearLayout main = new LinearLayout(activity);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(dp(12), dp(8), dp(12), dp(8));

        TextView title = text("🧩 الأنظمة", 16, true);
        title.setGravity(Gravity.CENTER);
        main.addView(title);

        LinearLayout modes = new LinearLayout(activity);
        Button start = button("▶️ إخفاء");
        start.setOnClickListener(v -> closePanel()); // returns to the game
        Button edit = button("🛠️ EDIT MODE");
        edit.setOnClickListener(v -> toast("غير متاح: يحتاج طبقة Native لعالم اللعبة (المرحلة 5)."));
        modes.addView(start, weight());
        modes.addView(edit, weight());
        main.addView(modes);

        ScrollView scroll = new ScrollView(activity);
        content = new LinearLayout(activity);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);
        main.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        Button close = button("✖ إغلاق الأنظمة");
        close.setOnClickListener(v -> closePanel());
        main.addView(close, row());

        panelRoot.addView(main, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(dp(330), -1, Gravity.START);
        sp.setMargins(dp(4), dp(44), 0, 0);
        uiLayout.addView(panelRoot, sp);
        showHome();
    }

    private void closePanel() {
        if (panelRoot != null && uiLayout != null) uiLayout.removeView(panelRoot);
        panelRoot = null;
        content = null;
    }

    private void showHome() {
        content.removeAllViews();
        List<String[]> all = allSystems();
        LinearLayout rowL = null;
        for (int i = 0; i < all.size(); i++) {
            if (i % 2 == 0) { rowL = new LinearLayout(activity); content.addView(rowL, row()); }
            final String[] sys = all.get(i);
            TextView b = chip(sys[0], Color.rgb(35, 45, 60));
            b.setOnClickListener(v -> showEditor(sys));
            rowL.addView(b, weight());
        }
        Button gen = button("📄 توليد new.pwn (يجمع ملفات الأنظمة)");
        gen.setOnClickListener(v -> generateNewPwn());
        content.addView(gen, row());
        Button ai = button("🤖 NAVARA AI — غير متاح (يحتاج مفتاح API)");
        ai.setEnabled(false);
        content.addView(ai, row());
        Button add = button("＋ إضافة نظام");
        add.setOnClickListener(v -> showAddSystem());
        content.addView(add, row());
    }

    private void showAddSystem() {
        content.removeAllViews();
        content.addView(text("＋ إضافة نظام جديد", 16, true));
        final EditText icon = edit("الأيقونة (إيموجي، مثال: 🎣)", false);
        final EditText name = edit("اسم النظام", false);
        final EditText desc = edit("الوصف", false);
        content.addView(icon, row());
        content.addView(name, row());
        content.addView(desc, row());
        Button ok = button("💾 إنشاء (ينشئ ملف Pawn خاص به)");
        ok.setOnClickListener(v -> {
            String n = name.getText().toString().trim().replace("|", " ");
            if (n.isEmpty()) { toast("اكتب اسم النظام أولاً."); return; }
            String ic = icon.getText().toString().trim().replace("|", " ");
            String d = desc.getText().toString().trim().replace("|", " ").replace("\n", " ");
            int count = readFile(new File(projectDir, "systems.txt")).split("\n").length;
            String key = "custom" + count + "_" + Math.abs(n.hashCode() % 10000);
            try {
                writeFile(new File(projectDir, "systems.txt"),
                        readFile(new File(projectDir, "systems.txt")) + (ic.isEmpty() ? "🧩" : ic) + " " + n + "|" + key + "|" + d + "\n");
                toast("تم إنشاء النظام. ملفه: " + key + ".pwn");
                showHome();
            } catch (Exception e) { toast("فشل الحفظ: " + e.getMessage()); }
        });
        content.addView(ok, row());
        Button back = button("← رجوع");
        back.setOnClickListener(v -> showHome());
        content.addView(back, row());
    }

    private void showEditor(final String[] sys) {
        content.removeAllViews();
        final File file = new File(projectDir, sys[1] + ".pwn");
        content.addView(text(sys[0] + "  —  " + file.getName(), 15, true));
        if (sys.length > 2 && !sys[2].isEmpty()) content.addView(text(sys[2], 12, false));

        final EditText code = edit("اكتب أو الصق كود Pawn هنا...", true);
        code.setTypeface(Typeface.MONOSPACE);
        code.setTextSize(11);
        code.setMinLines(10);
        String existing = readFile(file);
        code.setText(existing.isEmpty() ? template(sys) : existing);
        content.addView(code, new LinearLayout.LayoutParams(-1, -2));

        final TextView status = text(existing.isEmpty() ? "ملف جديد: أُدخل قالب ابتدائي (لم يُحفظ بعد)." : "", 12, false);

        LinearLayout r1 = new LinearLayout(activity);
        TextView save = chip("💾 حفظ", Color.rgb(24, 95, 165));
        save.setOnClickListener(v -> {
            try {
                if (file.exists()) copy(file, new File(backupDir, stamp() + "_" + file.getName()));
                writeFile(file, code.getText().toString());
                status.setText("✅ تم الحفظ (مع نسخة احتياطية): " + file.getAbsolutePath());
            } catch (Exception e) { status.setText("❌ فشل الحفظ: " + e.getMessage()); }
        });
        TextView check = chip("🔍 فحص", Color.rgb(35, 45, 60));
        check.setOnClickListener(v -> status.setText(checkBrackets(code.getText().toString())));
        TextView fmt = chip("🎨 تنسيق", Color.rgb(35, 45, 60));
        fmt.setOnClickListener(v -> {
            try {
                writeFile(new File(backupDir, stamp() + "_beforeformat_" + file.getName()), code.getText().toString());
                code.setText(formatPawn(code.getText().toString()));
                status.setText("✅ تم التنسيق (النسخة القديمة محفوظة في backups).");
            } catch (Exception e) { status.setText("❌ فشل التنسيق: " + e.getMessage()); }
        });
        TextView tpl = chip("📄 قالب", Color.rgb(35, 45, 60));
        tpl.setOnClickListener(v -> {
            code.setText(template(sys));
            status.setText("تم إدخال القالب. اضغط حفظ للاحتفاظ به.");
        });
        r1.addView(save, weight());
        r1.addView(check, weight());
        r1.addView(fmt, weight());
        r1.addView(tpl, weight());
        content.addView(r1, row());

        final EditText find = edit("بحث", false);
        final EditText repl = edit("استبدال بـ", false);
        LinearLayout r2 = new LinearLayout(activity);
        r2.addView(find, weight());
        r2.addView(repl, weight());
        content.addView(r2, row());
        LinearLayout r3 = new LinearLayout(activity);
        TextView doFind = chip("🔎 بحث", Color.rgb(35, 45, 60));
        doFind.setOnClickListener(v -> {
            String f = find.getText().toString();
            String t = code.getText().toString();
            if (f.isEmpty()) { status.setText("اكتب كلمة البحث."); return; }
            int idx = t.indexOf(f);
            if (idx < 0) { status.setText("لم يُعثر على النص."); return; }
            int line = 1;
            for (int i = 0; i < idx; i++) if (t.charAt(i) == '\n') line++;
            code.requestFocus();
            code.setSelection(idx, idx + f.length());
            status.setText("وُجد " + countOf(t, f) + " مرة. أول نتيجة في السطر " + line + ".");
        });
        TextView doRepl = chip("🔁 استبدال الكل", Color.rgb(35, 45, 60));
        doRepl.setOnClickListener(v -> {
            String f = find.getText().toString();
            if (f.isEmpty()) { status.setText("اكتب كلمة البحث."); return; }
            String t = code.getText().toString();
            int n = countOf(t, f);
            code.setText(t.replace(f, repl.getText().toString()));
            status.setText("تم استبدال " + n + " موضع. (لم يُحفظ بعد.)");
        });
        r3.addView(doFind, weight());
        r3.addView(doRepl, weight());
        content.addView(r3, row());

        for (String d : new String[]{"🤖 إنشاء الكود بـ AI — غير متاح (يحتاج مفتاح API)",
                "🔧 Auto Fix — غير متاح (يحتاج AI)",
                "⚙️ Build إلى new.amx — غير متاح (يحتاج pawncc/سيرفر بناء)"}) {
            Button b = button(d);
            b.setEnabled(false);
            content.addView(b, row());
        }
        content.addView(status, row());

        Button back = button("← رجوع للأنظمة");
        back.setOnClickListener(v -> showHome());
        content.addView(back, row());
    }

    private String template(String[] sys) {
        String key = sys[1];
        StringBuilder camel = new StringBuilder();
        for (String p : key.split("_")) if (!p.isEmpty()) camel.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1));
        String guard = "_navara_" + key + "_included";
        return "// NAVARA system: " + key + "\n"
                + "#if defined " + guard + "\n    #endinput\n#endif\n#define " + guard + "\n\n"
                + "stock Navara_" + camel + "_Init()\n{\n    print(\"[NAVARA] " + key + " loaded\");\n    return 1;\n}\n";
    }

    private void generateNewPwn() {
        StringBuilder sb = new StringBuilder("// Generated by NAVARA Studio\n#include <a_samp>\n\n");
        int n = 0;
        for (String[] sys : allSystems()) {
            File f = new File(projectDir, sys[1] + ".pwn");
            if (f.exists() && f.length() > 0) { sb.append("#include \"").append(sys[1]).append(".pwn\"\n"); n++; }
        }
        sb.append("\nmain() {}\n");
        try {
            File out = new File(projectDir, "new.pwn");
            if (out.exists()) copy(out, new File(backupDir, stamp() + "_new.pwn"));
            writeFile(out, sb.toString());
            toast("تم توليد new.pwn وفيه " + n + " نظام: " + out.getAbsolutePath());
        } catch (Exception e) { toast("فشل: " + e.getMessage()); }
    }

    private int countOf(String t, String f) {
        int c = 0, i = 0;
        while ((i = t.indexOf(f, i)) >= 0) { c++; i += f.length(); }
        return c;
    }

    /** Simple brace-based re-indent (4 spaces). Not a full Pawn formatter. */
    private String formatPawn(String src) {
        StringBuilder out = new StringBuilder();
        int depth = 0;
        boolean inBlock = false;
        for (String raw : src.split("\n", -1)) {
            String line = raw.trim();
            int opens = 0, closes = 0, leading = 0;
            boolean inStr = false, seen = false;
            for (int i = 0; i < line.length(); i++) {
                char c = line.charAt(i);
                char n = i + 1 < line.length() ? line.charAt(i + 1) : 0;
                if (inBlock) { if (c == '*' && n == '/') { inBlock = false; i++; } continue; }
                if (inStr) { if (c == '\\') i++; else if (c == '"') inStr = false; continue; }
                if (c == '/' && n == '/') break;
                if (c == '/' && n == '*') { inBlock = true; i++; continue; }
                if (c == '"') { inStr = true; seen = true; continue; }
                if (c == '{') { opens++; seen = true; }
                else if (c == '}') { closes++; if (!seen) leading++; }
                else if (!Character.isWhitespace(c)) seen = true;
            }
            int d = Math.max(0, depth - leading);
            if (!line.isEmpty()) for (int k = 0; k < d; k++) out.append("    ");
            out.append(line).append('\n');
            depth = Math.max(0, depth + opens - closes);
        }
        return out.toString().replaceAll("\n+$", "\n");
    }

    // ---------- logic ----------

    /** Very simple structural check: unbalanced (), {}, [] outside strings/comments. Reports line number. */
    private String checkBrackets(String src) {
        List<int[]> stack = new ArrayList<>();
        int line = 1;
        boolean inStr = false, inLine = false, inBlock = false;
        for (int i = 0; i < src.length(); i++) {
            char c = src.charAt(i);
            char n = i + 1 < src.length() ? src.charAt(i + 1) : 0;
            if (c == '\n') { line++; inLine = false; continue; }
            if (inLine) continue;
            if (inBlock) { if (c == '*' && n == '/') { inBlock = false; i++; } continue; }
            if (inStr) { if (c == '\\') i++; else if (c == '"') inStr = false; continue; }
            if (c == '/' && n == '/') { inLine = true; continue; }
            if (c == '/' && n == '*') { inBlock = true; i++; continue; }
            if (c == '"') { inStr = true; continue; }
            if (c == '(' || c == '{' || c == '[') stack.add(new int[]{c, line});
            else if (c == ')' || c == '}' || c == ']') {
                char open = c == ')' ? '(' : c == '}' ? '{' : '[';
                if (stack.isEmpty() || stack.get(stack.size() - 1)[0] != open)
                    return "❌ السطر " + line + ": الحرف '" + c + "' بلا مقابل.";
                stack.remove(stack.size() - 1);
            }
        }
        if (!stack.isEmpty()) {
            int[] t = stack.get(stack.size() - 1);
            return "❌ السطر " + t[1] + ": الحرف '" + (char) t[0] + "' لم يُغلق.";
        }
        return "✅ الأقواس متوازنة. (هذا ليس Compile حقيقي.)";
    }

    private List<String[]> allSystems() {
        List<String[]> l = new ArrayList<>();
        for (String[] d : DEFAULT_SYSTEMS) l.add(d);
        for (String line : readFile(new File(projectDir, "systems.txt")).split("\n")) {
            if (line.trim().isEmpty()) continue;
            String[] p = line.split("\\|", 3);
            if (p.length >= 2) l.add(new String[]{p[0].trim(), p[1].trim(), p.length > 2 ? p[2].trim() : ""});
            else l.add(new String[]{line.trim(), "custom_" + Math.abs(line.hashCode()), ""});
        }
        return l;
    }

    private String stamp() { return new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()); }

    private String readFile(File f) {
        if (!f.exists()) return "";
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f), "UTF-8"))) {
            StringBuilder sb = new StringBuilder();
            String l;
            while ((l = r.readLine()) != null) sb.append(l).append('\n');
            return sb.toString();
        } catch (Exception e) { return ""; }
    }

    private void writeFile(File f, String data) throws Exception {
        try (FileOutputStream o = new FileOutputStream(f)) { o.write(data.getBytes("UTF-8")); }
    }

    private void copy(File a, File b) throws Exception {
        try (FileInputStream i = new FileInputStream(a); FileOutputStream o = new FileOutputStream(b)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = i.read(buf)) > 0) o.write(buf, 0, n);
        }
    }

    // ---------- ui helpers ----------

    private void toast(String s) { Toast.makeText(activity, s, Toast.LENGTH_LONG).show(); }

    private TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(activity);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(size);
        t.setPadding(0, dp(6), 0, dp(6));
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private Button button(String s) {
        Button b = new Button(activity);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15);
        b.setBackground(rounded(Color.rgb(35, 45, 60), 12));
        return b;
    }

    private EditText edit(String hint, boolean multi) {
        EditText e = new EditText(activity);
        e.setHint(hint);
        e.setHintTextColor(Color.GRAY);
        e.setTextColor(Color.WHITE);
        e.setBackground(rounded(Color.rgb(25, 31, 41), 10));
        e.setPadding(dp(10), dp(10), dp(10), dp(10));
        e.setInputType(multi ? (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS)
                : InputType.TYPE_CLASS_TEXT);
        e.setGravity(Gravity.TOP | Gravity.START);
        return e;
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private LinearLayout.LayoutParams row() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(4), 0, dp(4));
        return p;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1);
        p.setMargins(dp(4), dp(4), dp(4), dp(4));
        return p;
    }


    // =====================================================================
    //  BUILDER HUD (top bar + left tools + right properties + bottom bar)
    //  Data model + Save/Undo/Redo are real. Applying to the game world is
    //  NOT implemented yet (needs the native layer) and is stated in the UI.
    // =====================================================================

    private static class Item {
        int id; String type; int model; int world; int interior;
        float[] pos = new float[3];
        float[] rot = new float[3];
        float[] scale = {1f, 1f, 1f};
        String label() { return type + " (ID: " + model + ")"; }
    }

    private static final String[][] TOOLS = {
            {"Object", "إضافة كائن", "📦"}, {"Building", "إضافة مبنى", "🏢"},
            {"Vehicle", "إضافة مركبة", "🚗"}, {"NPC", "إضافة NPC", "👤"},
            {"Pickup", "إضافة Pickup", "🎁"}, {"Marker", "إضافة علامة", "📍"},
            {"Light", "إضافة إضاءة", "💡"}, {"Gate", "إضافة بوابة", "🚧"}
    };

    private final List<Item> items = new ArrayList<>();
    private final List<String> undoStack = new ArrayList<>();
    private final List<String> redoStack = new ArrayList<>();
    private int selectedId = -1;
    private FrameLayout hud;
    private LinearLayout recentBox;
    private ScrollView rightScroll;
    private LinearLayout rightBox;

    private void openHud() {
        if (hud != null || uiLayout == null) return;
        if (fab != null) fab.setVisibility(View.GONE);

        hud = new FrameLayout(activity); // NOT clickable: touches in the middle reach the game

        // ---- top bar
        HorizontalScrollView topScroll = new HorizontalScrollView(activity);
        topScroll.setBackgroundColor(Color.argb(235, 12, 17, 24));
        LinearLayout top = new LinearLayout(activity);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(8), 0, dp(8), 0);
        top.addView(label("NAVARA STUDIO", 14, true), new LinearLayout.LayoutParams(-2, -2));
        top.addView(label("   Project: NAVARA RP · Mode: Build   ", 11, false));
        top.addView(topBtn("💾 Save", v -> saveProject()));
        top.addView(topBtn("↶ Undo", v -> undo()));
        top.addView(topBtn("↷ Redo", v -> redo()));
        top.addView(topBtn("🕊 طيران", v -> toast("غير متاح: الكاميرا الحرة تحتاج طبقة Native (المرحلة 5).")));
        top.addView(topBtn("🧩 الأنظمة", v -> openPanel()));
        top.addView(topBtn("▶ Play", v -> closeHud()));
        top.addView(topBtn("✖", v -> closeHud()));
        topScroll.addView(top);
        hud.addView(topScroll, new FrameLayout.LayoutParams(-1, dp(40), Gravity.TOP));

        // ---- left: tools + recent
        ScrollView leftScroll = new ScrollView(activity);
        LinearLayout left = new LinearLayout(activity);
        left.setOrientation(LinearLayout.VERTICAL);
        left.setBackground(rounded(Color.argb(225, 14, 19, 27), 10));
        left.setPadding(dp(6), dp(6), dp(6), dp(6));
        left.addView(label("أدوات البناء", 13, true));
        for (String[] t : TOOLS) {
            final String type = t[0];
            TextView row = chip(t[2] + "  " + t[1], Color.rgb(28, 37, 50));
            row.setOnClickListener(v -> addItem(type));
            left.addView(row, row());
        }
        left.addView(label("العناصر الحديثة", 13, true));
        recentBox = new LinearLayout(activity);
        recentBox.setOrientation(LinearLayout.VERTICAL);
        left.addView(recentBox);
        leftScroll.addView(left);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(165), -1, Gravity.START);
        lp.setMargins(dp(4), dp(44), 0, dp(60));
        hud.addView(leftScroll, lp);

        // ---- right: properties
        rightScroll = new ScrollView(activity);
        rightBox = new LinearLayout(activity);
        rightBox.setOrientation(LinearLayout.VERTICAL);
        rightBox.setBackground(rounded(Color.argb(225, 14, 19, 27), 10));
        rightBox.setPadding(dp(8), dp(6), dp(8), dp(6));
        rightScroll.addView(rightBox);
        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(dp(190), -2, Gravity.END);
        rp.setMargins(0, dp(44), dp(4), dp(60));
        hud.addView(rightScroll, rp);

        // ---- bottom toolbar
        HorizontalScrollView botScroll = new HorizontalScrollView(activity);
        LinearLayout bot = new LinearLayout(activity);
        bot.setBackground(rounded(Color.argb(235, 14, 19, 27), 10));
        bot.setPadding(dp(4), dp(4), dp(4), dp(4));
        for (String[] t : TOOLS) {
            final String type = t[0];
            TextView b = chip(t[2] + "\nAdd " + t[0], Color.rgb(28, 37, 50));
            b.setGravity(Gravity.CENTER);
            b.setOnClickListener(v -> addItem(type));
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(78), dp(48));
            bp.setMargins(dp(3), 0, dp(3), 0);
            bot.addView(b, bp);
        }
        botScroll.addView(bot);
        FrameLayout.LayoutParams bpp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        bpp.setMargins(dp(170), 0, dp(195), dp(4));
        hud.addView(botScroll, bpp);

        uiLayout.addView(hud, new FrameLayout.LayoutParams(-1, -1));
        refreshBuilder();
    }

    private void closeHud() {
        if (hud != null && uiLayout != null) uiLayout.removeView(hud);
        hud = null;
        if (fab != null) fab.setVisibility(View.VISIBLE);
    }

    private void addItem(String type) {
        pushUndo();
        Item it = new Item();
        int max = 0;
        for (Item x : items) max = Math.max(max, x.id);
        it.id = max + 1;
        it.type = type;
        items.add(it);
        selectedId = it.id;
        refreshBuilder();
        toast("أُضيف \"" + type + "\" للمشروع. (لن يظهر داخل عالم اللعبة قبل ربط Native.)");
    }

    private Item selected() {
        for (Item x : items) if (x.id == selectedId) return x;
        return null;
    }

    private void refreshBuilder() {
        if (hud == null) return;
        recentBox.removeAllViews();
        int shown = 0;
        for (int i = items.size() - 1; i >= 0 && shown < 6; i--, shown++) {
            final Item it = items.get(i);
            TextView r = chip(it.label(), it.id == selectedId ? Color.rgb(24, 95, 165) : Color.rgb(28, 37, 50));
            r.setOnClickListener(v -> { selectedId = it.id; refreshBuilder(); });
            recentBox.addView(r, row());
        }
        if (items.isEmpty()) recentBox.addView(label("لا توجد عناصر بعد.", 11, false));

        rightBox.removeAllViews();
        final Item s = selected();
        rightScroll.setVisibility(s == null ? View.GONE : View.VISIBLE);
        if (s == null) return;

        rightBox.addView(label("خصائص العنصر", 13, true));
        rightBox.addView(label(s.label(), 12, false));
        final EditText[] pos = fields("Position", s.pos);
        final EditText[] rot = fields("Rotation", s.rot);
        final EditText[] scl = fields("Scale", s.scale);
        final EditText model = single("Model ID", String.valueOf(s.model));
        final EditText world = single("World", String.valueOf(s.world));
        final EditText interior = single("Interior", String.valueOf(s.interior));

        LinearLayout btns = new LinearLayout(activity);
        TextView upd = chip("✔ تحديث", Color.rgb(24, 95, 165));
        upd.setOnClickListener(v -> {
            pushUndo();
            read(pos, s.pos); read(rot, s.rot); read(scl, s.scale);
            s.model = (int) num(model); s.world = (int) num(world); s.interior = (int) num(interior);
            refreshBuilder();
            toast("تم تحديث العنصر في المشروع.");
        });
        TextView del = chip("🗑 حذف", Color.rgb(163, 45, 45));
        del.setOnClickListener(v -> {
            pushUndo();
            items.remove(s);
            selectedId = -1;
            refreshBuilder();
            toast("تم حذف العنصر (يمكنك Undo).");
        });
        btns.addView(upd, weight());
        btns.addView(del, weight());
        rightBox.addView(btns);
    }

    private EditText[] fields(String title, float[] v) {
        rightBox.addView(label(title, 12, true));
        LinearLayout r = new LinearLayout(activity);
        EditText[] e = new EditText[3];
        String[] ax = {"X", "Y", "Z"};
        for (int i = 0; i < 3; i++) {
            e[i] = edit(ax[i], false);
            e[i].setText(String.valueOf(v[i]));
            e[i].setTextSize(11);
            e[i].setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
            e[i].setPadding(dp(4), dp(4), dp(4), dp(4));
            r.addView(e[i], weight());
        }
        rightBox.addView(r);
        return e;
    }

    private EditText single(String title, String val) {
        rightBox.addView(label(title, 12, true));
        EditText e = edit(title, false);
        e.setText(val);
        e.setTextSize(12);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        rightBox.addView(e, row());
        return e;
    }

    private float num(EditText e) {
        try { return Float.parseFloat(e.getText().toString().trim()); } catch (Exception x) { return 0f; }
    }

    private void read(EditText[] e, float[] out) { for (int i = 0; i < 3; i++) out[i] = num(e[i]); }

    // ---- save / undo / redo (real)
    private void pushUndo() { undoStack.add(snapshot()); redoStack.clear(); if (undoStack.size() > 100) undoStack.remove(0); }

    private void undo() {
        if (undoStack.isEmpty()) { toast("لا يوجد شيء للتراجع عنه."); return; }
        redoStack.add(snapshot());
        restore(undoStack.remove(undoStack.size() - 1));
        if (selected() == null) selectedId = -1;
        refreshBuilder();
    }

    private void redo() {
        if (redoStack.isEmpty()) { toast("لا يوجد شيء لإعادته."); return; }
        undoStack.add(snapshot());
        restore(redoStack.remove(redoStack.size() - 1));
        if (selected() == null) selectedId = -1;
        refreshBuilder();
    }

    private void saveProject() {
        try {
            File f = new File(projectDir, "objects.json");
            if (f.exists()) copy(f, new File(backupDir, stamp() + "_objects.json"));
            writeFile(f, snapshot());
            toast("تم حفظ المشروع: " + f.getAbsolutePath());
        } catch (Exception e) { toast("فشل الحفظ: " + e.getMessage()); }
    }

    private JSONArray arr(float[] f) throws JSONException {
        JSONArray a = new JSONArray();
        for (float v : f) a.put((double) v);
        return a;
    }

    private String snapshot() {
        JSONArray a = new JSONArray();
        try {
            for (Item it : items) {
                JSONObject o = new JSONObject();
                o.put("id", it.id); o.put("type", it.type); o.put("model", it.model);
                o.put("world", it.world); o.put("interior", it.interior);
                o.put("pos", arr(it.pos)); o.put("rot", arr(it.rot)); o.put("scale", arr(it.scale));
                a.put(o);
            }
        } catch (JSONException ignored) { }
        return a.toString();
    }

    private void restore(String json) {
        items.clear();
        try {
            JSONArray a = new JSONArray(json.trim());
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Item it = new Item();
                it.id = o.getInt("id"); it.type = o.getString("type"); it.model = o.getInt("model");
                it.world = o.getInt("world"); it.interior = o.getInt("interior");
                JSONArray p = o.getJSONArray("pos"), r = o.getJSONArray("rot"), s = o.getJSONArray("scale");
                for (int k = 0; k < 3; k++) {
                    it.pos[k] = (float) p.getDouble(k);
                    it.rot[k] = (float) r.getDouble(k);
                    it.scale[k] = (float) s.getDouble(k);
                }
                items.add(it);
            }
        } catch (JSONException ignored) { }
    }

    // ---- small ui helpers for the HUD
    private TextView label(String s, int size, boolean bold) { TextView t = text(s, size, bold); return t; }

    private TextView chip(String s, int color) {
        TextView t = new TextView(activity);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(12);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(8), dp(7), dp(8), dp(7));
        t.setBackground(rounded(color, 8));
        return t;
    }

    private TextView topBtn(String s, View.OnClickListener l) {
        TextView t = chip(s, Color.rgb(28, 37, 50));
        t.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.setMargins(dp(3), dp(3), dp(3), dp(3));
        t.setLayoutParams(p);
        return t;
    }

    public void close() { closePanel(); closeHud(); }
}
